#!/bin/bash

echo "TODO scripts:"

echo "1. check out an appropriate version of the repo"
echo "2. add license info"
echo "3. copy appropriate files into the repo for github"
echo "4. push to github"
echo "5. zip appropriate files for archive"

exit 1

